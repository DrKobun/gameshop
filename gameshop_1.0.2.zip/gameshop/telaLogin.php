<?php
include('Conexao.php');

if (isset($_POST['email']) && isset($_POST['senha'])) {
    if (strlen($_POST['email']) == 0) {
        echo "Preencha seu email";
    } elseif (strlen($_POST['senha']) == 0) {
        echo "Preencha sua senha";
    } else {
        $email = $_POST['email'];
        $senha = $_POST['senha'];

        try {
            $pdo = Conexao::getInstance();

            $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = :email AND senha = :senha");
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
            $stmt->bindParam(':senha', $senha, PDO::PARAM_STR);
            $stmt->execute();
            
            // Verifica se encontrou um usuário com o email e senha fornecidos
            if ($stmt->rowCount() == 1) {
                $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                
                session_start();
                $_SESSION['id'] = $usuario['id'];
                $_SESSION['nome'] = $usuario['nome'];
                
                
                header("Location: index.php"); // Redireciona para a página principal
                exit(); // Termina o script após o redirecionamento
            } else {
                echo "Usuário ou senha incorretos";
            }
        } catch(PDOException $e) {
            echo "Falha na execução do código SQL: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <center>
    <form action="" method="POST" style="padding-top: 350px;">
        <label for="">Username</label>
        <input type="text" name="email">
        <br><br>
        <label for="">Senha</label>
        <input type="password" name="senha"> <!-- Use type="password" para esconder a senha -->
        <br><br>
        <button type="submit">Entrar</button>
    </form>
    </center>
</body>
</html>
